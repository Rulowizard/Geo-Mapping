

API_KEY ="pk.eyJ1IjoicnVsb3dpemFyZCIsImEiOiJjanR1dWtmdDcxcWswNDVtdWltZ3FjNDdvIn0.k98udPHC0_C1FhpcfKoWdQ";


var link = "https://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_week.geojson";

// Create a map object
var myMap = L.map("map", {
  center: [19.4326, -99.1334],
  zoom: 4
});

L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
  attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
  maxZoom: 18,
  id: "mapbox.light",
  accessToken: API_KEY
}).addTo(myMap);

function getColor(mag){
    return mag > 5 ? '#800026' :
           mag > 4 ? '#BD0026' :
           mag > 3 ? '#FD8D3C' :
           mag > 2 ? '#FED976' :
                     '#FFEDA0';
}




d3.json(link, function(data) {
    
    
    console.log(data)
    info=data.features
     for( var i=0 ; i<info.length;i++ ){
         
         coordinates = [ info[i].geometry.coordinates[1], info[i].geometry.coordinates[0] ]
         
         mag = parseFloat( info[i].properties.mag)
         
        L.circle(coordinates,{
            fillOpacity: 0.5,
            color: getColor(mag) ,
            fillColor: getColor(mag) ,
            weight:1,
            radius: mag*30000
        }).addTo(myMap);
         
     }
         
});



var legend = L.control({position:"bottomright"})
legend.onAdd = function(myMap){
    var div = L.DomUtil.create("div","info legend"),
        magnitude = [1,2,3,4,5],
        labels=[];
    
    for (var i=0; i<magnitude.length;i++){
        div.innerHTML += '<i style="background:' + getColor(magnitude[i] + 1) + '"></i> ' +
            magnitude[i] + (magnitude[i + 1] ? '&ndash;' + magnitude[i + 1] + '<br>' : '+');
    }
    
    return div;
};

legend.addTo(myMap);

